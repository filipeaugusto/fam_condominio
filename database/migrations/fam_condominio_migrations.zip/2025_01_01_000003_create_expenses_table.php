<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('condominium_id')->constrained()->cascadeOnDelete();
            $table->enum('type', ['fixed', 'variable', 'reserve']);
            $table->string('label');
            $table->decimal('amount', 10, 2);
            $table->date('due_date')->nullable();
            $table->boolean('included_in_closing')->default(false);
            $table->foreignId('monthly_closing_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('expenses');
    }
};